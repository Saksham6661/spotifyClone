import { useEffect, useState } from 'react';
import { api } from '../api/client';
import TrackList from './TrackList';

export default function DetailView({ kind, id, onBack }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    setData(null);
    const fetcher = kind === 'playlist' ? api.playlist(id) : api.album(id);
    fetcher.then(setData).catch((e) => setError(e.message));
  }, [kind, id]);

  if (error) return <p className="error">{error}</p>;
  if (!data) return <p className="muted">Loading…</p>;

  const title = data.name || data.title;
  const subtitle = data.description || `${data.artist_name} · ${data.year || ''}`;

  return (
    <div className="view">
      <button type="button" className="back-btn" onClick={onBack}>
        ← Back
      </button>
      <header className="detail-hero">
        <img src={data.cover_url} alt="" className="detail-cover" />
        <div>
          <p className="detail-type">{kind === 'playlist' ? 'Playlist' : 'Album'}</p>
          <h1>{title}</h1>
          <p className="muted">{subtitle}</p>
        </div>
      </header>
      <TrackList tracks={data.tracks} showAlbum={kind === 'playlist'} />
    </div>
  );
}
