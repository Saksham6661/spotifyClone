import { useEffect, useState } from 'react';
import { api } from '../api/client';
import CardGrid from './CardGrid';
import TrackList from './TrackList';

export default function HomeView({ onOpen }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.home()
      .then(setData)
      .catch((e) => setError(e.message));
  }, []);

  if (error) return <p className="error">{error}</p>;
  if (!data) return <p className="muted">Loading home…</p>;

  return (
    <div className="view">
      <header className="view-hero">
        <h1>Good evening</h1>
        <p className="muted">Your local Spotify demo — pick a playlist or hit play.</p>
      </header>
      <CardGrid title="Made for you" items={data.playlists} type="playlist" onOpen={onOpen} />
      <CardGrid title="Jump back in" items={data.albums} type="album" onOpen={onOpen} />
      <section className="section">
        <h2>Recently added</h2>
        <TrackList tracks={data.recent} showAlbum />
      </section>
    </div>
  );
}
