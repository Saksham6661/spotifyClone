export function IconLyrics() {
  return (
    <svg role="img" aria-hidden="true" viewBox="0 0 16 16" width="16" height="16">
      <path
        fill="currentColor"
        d="M11.5 1.5a1 1 0 0 1 1 1v3.5a1 1 0 0 1-1 1h-1v5.5a3.5 3.5 0 1 1-1.5-.5V6h-1a1 1 0 0 1-1-1V2.5a1 1 0 0 1 1-1h3.5zm-2 9.5a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"
      />
    </svg>
  );
}

export function IconQueue() {
  return (
    <svg role="img" aria-hidden="true" viewBox="0 0 16 16" width="16" height="16">
      <path
        fill="currentColor"
        d="M3 3.75a.75.75 0 0 1 .75-.75h8.5a.75.75 0 0 1 0 1.5h-8.5A.75.75 0 0 1 3 3.75zm0 4a.75.75 0 0 1 .75-.75h8.5a.75.75 0 0 1 0 1.5h-8.5A.75.75 0 0 1 3 7.75zm0 4a.75.75 0 0 1 .75-.75h5.5a.75.75 0 0 1 0 1.5h-5.5A.75.75 0 0 1 3 11.75zM1.5 9.25v-1.5l3 1.75-3 1.75v-1.5z"
      />
    </svg>
  );
}

export function IconDevice() {
  return (
    <svg role="img" aria-hidden="true" viewBox="0 0 16 16" width="16" height="16">
      <path
        fill="currentColor"
        d="M1.5 2.75A1.25 1.25 0 0 1 2.75 1.5h8.5A1.25 1.25 0 0 1 12.5 2.75v5.5A1.25 1.25 0 0 1 11.25 9.5H9.5v.75h1a.625.625 0 1 1 0 1.25h-4a.625.625 0 0 1 0-1.25h1V9.5H2.75A1.25 1.25 0 0 1 1.5 8.25v-5.5zM2.75 2.5a.25.25 0 0 0-.25.25v5.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5z"
      />
      <path
        fill="currentColor"
        d="M10.75 8.5a.75.75 0 0 1 .75-.75h3.5a.75.75 0 0 1 .75.75v5a.75.75 0 0 1-.75.75h-3.5a.75.75 0 0 1-.75-.75v-5zm1.25.75v3.5h2v-3.5h-2z"
      />
    </svg>
  );
}

export function IconVolume({ level = 0.8 }) {
  if (level === 0) {
    return (
      <svg role="img" aria-hidden="true" viewBox="0 0 16 16" width="16" height="16">
        <path
          fill="currentColor"
          d="M9.741.85a.75.75 0 0 1 .375.65v13a.75.75 0 0 1-1.125.65l-6.925-4a.75.75 0 0 0-.375-.125H.75A.75.75 0 0 1 0 10.75v-5.5A.75.75 0 0 1 .75 4.5h1.5a.75.75 0 0 0 .375-.125l6.925-4a.75.75 0 0 1 .741.475zM1.5 5.25v5.5h.75a2.25 2.25 0 0 0 1.125-.3l5.925-3.425v-3.05L3.375 5.55A2.25 2.25 0 0 0 2.25 5.25H1.5z"
        />
        <path
          fill="currentColor"
          d="m14.73 3.08-.75-.75-8.5 8.5.75.75 8.5-8.5z"
        />
      </svg>
    );
  }

  return (
    <svg role="img" aria-hidden="true" viewBox="0 0 16 16" width="16" height="16">
      <path
        fill="currentColor"
        d="M9.741.85a.75.75 0 0 1 .375.65v13a.75.75 0 0 1-1.125.65l-6.925-4a.75.75 0 0 0-.375-.125H.75A.75.75 0 0 1 0 10.75v-5.5A.75.75 0 0 1 .75 4.5h1.5a.75.75 0 0 0 .375-.125l6.925-4a.75.75 0 0 1 .741.475z"
      />
      {level > 0.5 && (
        <path
          fill="currentColor"
          d="M14.5 4.5a.75.75 0 0 1 0 1.06l-2 2a.75.75 0 1 1-1.06-1.06l2-2a.75.75 0 0 1 1.06 0z"
        />
      )}
      {level > 0 && (
        <path
          fill="currentColor"
          d="M12.5 2.5a.75.75 0 0 1 0 1.06l-4 4a.75.75 0 1 1-1.06-1.06l4-4a.75.75 0 0 1 1.06 0z"
        />
      )}
    </svg>
  );
}

export function IconMiniPlayer() {
  return (
    <svg role="img" aria-hidden="true" viewBox="0 0 16 16" width="16" height="16">
      <path
        fill="currentColor"
        d="M2 2.5A1.5 1.5 0 0 1 3.5 1h9A1.5 1.5 0 0 1 14 2.5v9A1.5 1.5 0 0 1 12.5 13H3.5A1.5 1.5 0 0 1 2 11.5v-9zM3.5 2a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-9z"
      />
      <path
        fill="currentColor"
        d="M8.5 8.5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-4z"
      />
    </svg>
  );
}

export function IconFullscreen() {
  return (
    <svg role="img" aria-hidden="true" viewBox="0 0 16 16" width="16" height="16">
      <path
        fill="currentColor"
        d="M1.75 1.75a.75.75 0 0 1 1.06 0L5 3.94V2.5a.75.75 0 0 1 1.5 0v3.25A.75.75 0 0 1 5.75 6.5H2.5a.75.75 0 0 1 0-1.5h1.44L1.75 2.81a.75.75 0 0 1 0-1.06zM14.25 1.75a.75.75 0 0 0-1.06 0L11 3.94V2.5a.75.75 0 0 0-1.5 0v3.25c0 .414.336.75.75.75h3.25a.75.75 0 0 0 0-1.5h-1.44l1.69-1.69a.75.75 0 0 0 0-1.06zM1.75 14.25a.75.75 0 0 0 1.06 0L5 12.06v1.44a.75.75 0 0 0 1.5 0v-3.25a.75.75 0 0 0-.75-.75H2.5a.75.75 0 0 0 0 1.5h1.44l-1.69 1.69a.75.75 0 0 0 0 1.06zM14.25 14.25a.75.75 0 0 1-1.06 0L11 12.06v1.44a.75.75 0 0 1-1.5 0v-3.25c0-.414.336-.75.75-.75h3.25a.75.75 0 0 1 0 1.5h-1.44l1.69 1.69a.75.75 0 0 1 0 1.06z"
      />
    </svg>
  );
}
