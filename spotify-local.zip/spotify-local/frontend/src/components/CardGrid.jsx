import { usePlayerContext } from '../hooks/PlayerContext';

export default function CardGrid({ title, items, type, onOpen }) {
  const { playTrack } = usePlayerContext();

  return (
    <section className="section">
      <h2>{title}</h2>
      <div className="card-grid">
        {items.map((item) => (
          <button
            key={item.id}
            type="button"
            className="card"
            onClick={() => {
              if (type === 'track') playTrack(item, items);
              else onOpen?.(type, item.id);
            }}
          >
            <img src={item.cover_url || item.album_cover} alt="" className="card-img" />
            <div className="card-title">{item.name || item.title}</div>
            <div className="card-sub">
              {item.artist_name || item.description || `${item.track_count || 0} tracks`}
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}
