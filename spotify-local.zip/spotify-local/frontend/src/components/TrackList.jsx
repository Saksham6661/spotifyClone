import { usePlayerContext } from '../hooks/PlayerContext';

function formatDuration(ms) {
  const sec = Math.floor(ms / 1000);
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export default function TrackList({ tracks, showAlbum = false }) {
  const { playTrack, currentTrack } = usePlayerContext();

  if (!tracks?.length) {
    return <p className="muted empty">No tracks found.</p>;
  }

  return (
    <div className="track-list">
      <div className="track-list-header">
        <span>#</span>
        <span>Title</span>
        {showAlbum && <span>Album</span>}
        <span>Duration</span>
      </div>
      {tracks.map((track, i) => (
        <button
          key={track.id}
          type="button"
          className={`track-row ${currentTrack?.id === track.id ? 'playing' : ''}`}
          onClick={() => playTrack(track, tracks)}
        >
          <span className="track-num">{currentTrack?.id === track.id && '♪' || i + 1}</span>
          <span className="track-main">
            <img src={track.album_cover} alt="" className="track-thumb" />
            <span>
              <span className="track-title">{track.title}</span>
              <span className="track-artist">{track.artist_name}</span>
            </span>
          </span>
          {showAlbum && <span className="track-album">{track.album_title}</span>}
          <span className="track-dur">{formatDuration(track.duration_ms)}</span>
        </button>
      ))}
    </div>
  );
}
