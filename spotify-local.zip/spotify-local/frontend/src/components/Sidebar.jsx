export default function Sidebar({ view, onNavigate }) {
  const items = [
    { id: 'home', label: 'Home', icon: '🏠' },
    { id: 'search', label: 'Search', icon: '🔍' },
    { id: 'library', label: 'Your Library', icon: '📚' },
  ];

  return (
    <aside className="sidebar">
      <div className="logo">
        <span className="logo-icon">●</span>
        <span>Spotify Local</span>
      </div>
      <nav className="nav">
        {items.map((item) => (
          <button
            key={item.id}
            type="button"
            className={`nav-item ${view === item.id ? 'active' : ''}`}
            onClick={() => onNavigate(item.id)}
          >
            <span>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
      <div className="sidebar-playlists">
        <p className="sidebar-label">Playlists</p>
        <button type="button" className="nav-item subtle" onClick={() => onNavigate('library')}>
          Browse all playlists
        </button>
      </div>
    </aside>
  );
}
