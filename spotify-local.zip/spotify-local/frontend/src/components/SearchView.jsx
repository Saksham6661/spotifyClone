import { useEffect, useState } from 'react';
import { api } from '../api/client';
import TrackList from './TrackList';

export default function SearchView() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    const t = setTimeout(() => {
      setLoading(true);
      api
        .search(query)
        .then(setResults)
        .finally(() => setLoading(false));
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  return (
    <div className="view">
      <header className="view-hero">
        <h1>Search</h1>
        <input
          className="search-input"
          placeholder="What do you want to listen to?"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
        />
      </header>
      {loading && <p className="muted">Searching…</p>}
      {!loading && query && <TrackList tracks={results} showAlbum />}
      {!query && <p className="muted">Search tracks, artists, or albums.</p>}
    </div>
  );
}
