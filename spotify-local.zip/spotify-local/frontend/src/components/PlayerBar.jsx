import { usePlayerContext } from '../hooks/PlayerContext';

function formatTime(sec) {
  if (!sec || Number.isNaN(sec)) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export default function PlayerBar() {
  const {
    currentTrack,
    isPlaying,
    progress,
    duration,
    volume,
    setVolume,
    togglePlay,
    playNext,
    playPrev,
    seek,
  } = usePlayerContext();

  const pct = duration ? (progress / duration) * 100 : 0;

  return (
    <footer className="player-bar">
      <div className="player-track">
        {currentTrack ? (
          <>
            <img src={currentTrack.album_cover} alt="" className="player-cover" />
            <div>
              <div className="player-title">{currentTrack.title}</div>
              <div className="player-artist">{currentTrack.artist_name}</div>
            </div>
          </>
        ) : (
          <span className="muted">Select a track to play</span>
        )}
      </div>

      <div className="player-controls">
        <div className="control-buttons">
          <button type="button" className="icon-btn" onClick={playPrev} disabled={!currentTrack} aria-label="Previous">
            ⏮
          </button>
          <button type="button" className="play-btn" onClick={togglePlay} disabled={!currentTrack} aria-label="Play/Pause">
            {isPlaying ? '⏸' : '▶'}
          </button>
          <button type="button" className="icon-btn" onClick={playNext} disabled={!currentTrack} aria-label="Next">
            ⏭
          </button>
        </div>
        <div className="progress-row">
          <span className="time">{formatTime(progress)}</span>
          <input
            type="range"
            min="0"
            max="100"
            value={pct}
            onChange={(e) => seek(Number(e.target.value))}
            className="progress-slider"
            disabled={!currentTrack}
          />
          <span className="time">{formatTime(duration)}</span>
        </div>
      </div>

      <div className="player-volume">
        <span>🔊</span>
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={volume}
          onChange={(e) => setVolume(Number(e.target.value))}
          className="volume-slider"
        />
      </div>
    </footer>
  );
}
