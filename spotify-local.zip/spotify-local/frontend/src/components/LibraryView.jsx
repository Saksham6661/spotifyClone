import { useEffect, useState } from 'react';
import { api } from '../api/client';
import CardGrid from './CardGrid';

export default function LibraryView({ onOpen }) {
  const [playlists, setPlaylists] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.playlists()
      .then(setPlaylists)
      .catch((e) => setError(e.message));
  }, []);

  if (error) return <p className="error">{error}</p>;

  return (
    <div className="view">
      <header className="view-hero">
        <h1>Your Library</h1>
      </header>
      <CardGrid title="Playlists" items={playlists} type="playlist" onOpen={onOpen} />
    </div>
  );
}
