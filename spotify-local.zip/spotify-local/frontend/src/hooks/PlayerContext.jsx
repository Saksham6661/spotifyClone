import { createContext, useContext } from 'react';
import { usePlayer } from '../hooks/usePlayer';

const PlayerContext = createContext(null);

export function PlayerProvider({ children }) {
  const player = usePlayer();
  return <PlayerContext.Provider value={player}>{children}</PlayerContext.Provider>;
}

export function usePlayerContext() {
  const ctx = useContext(PlayerContext);
  if (!ctx) throw new Error('usePlayerContext must be used within PlayerProvider');
  return ctx;
}
