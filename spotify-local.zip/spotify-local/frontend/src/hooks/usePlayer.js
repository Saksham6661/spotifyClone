import { useCallback, useEffect, useRef, useState } from 'react';

export function usePlayer() {
  const audioRef = useRef(null);
  const queueRef = useRef([]);
  const queueIndexRef = useRef(0);
  const loadTrackRef = useRef(null);

  const [currentTrack, setCurrentTrack] = useState(null);
  const [queue, setQueue] = useState([]);
  const [queueIndex, setQueueIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);

  const loadTrack = useCallback(async (track, newQueue, index = 0) => {
    const audio = audioRef.current;
    if (!audio || !track) return;
    queueRef.current = newQueue;
    queueIndexRef.current = index;
    setCurrentTrack(track);
    setQueue(newQueue);
    setQueueIndex(index);
    audio.src = track.audio_url;
    setProgress(0);
    try {
      await audio.play();
    } catch {
      setIsPlaying(false);
    }
  }, []);

  loadTrackRef.current = loadTrack;

  useEffect(() => {
    const audio = new Audio();
    audio.volume = volume;
    audioRef.current = audio;

    const onTime = () => setProgress(audio.currentTime);
    const onMeta = () => setDuration(audio.duration || 0);
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onEnded = () => {
      const q = queueRef.current;
      if (!q.length) return;
      const next = (queueIndexRef.current + 1) % q.length;
      loadTrackRef.current?.(q[next], q, next);
    };

    audio.addEventListener('timeupdate', onTime);
    audio.addEventListener('loadedmetadata', onMeta);
    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('ended', onEnded);

    return () => {
      audio.pause();
      audio.removeEventListener('timeupdate', onTime);
      audio.removeEventListener('loadedmetadata', onMeta);
      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('ended', onEnded);
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);

  const playTrack = useCallback(
    (track, allTracks = []) => {
      const list = allTracks.length ? allTracks : [track];
      const idx = list.findIndex((t) => t.id === track.id);
      loadTrack(track, list, idx >= 0 ? idx : 0);
    },
    [loadTrack]
  );

  const togglePlay = useCallback(async () => {
    const audio = audioRef.current;
    if (!audio || !currentTrack) return;
    if (audio.paused) await audio.play();
    else audio.pause();
  }, [currentTrack]);

  const playNext = useCallback(() => {
    const q = queueRef.current;
    if (!q.length) return;
    const next = (queueIndexRef.current + 1) % q.length;
    loadTrack(q[next], q, next);
  }, [loadTrack]);

  const playPrev = useCallback(() => {
    const audio = audioRef.current;
    if (audio && audio.currentTime > 3) {
      audio.currentTime = 0;
      return;
    }
    const q = queueRef.current;
    if (!q.length) return;
    const prev = queueIndexRef.current === 0 ? q.length - 1 : queueIndexRef.current - 1;
    loadTrack(q[prev], q, prev);
  }, [loadTrack]);

  const seek = useCallback((pct) => {
    const audio = audioRef.current;
    if (!audio || !duration) return;
    audio.currentTime = (pct / 100) * duration;
  }, [duration]);

  return {
    currentTrack,
    queue,
    queueIndex,
    isPlaying,
    progress,
    duration,
    volume,
    setVolume,
    playTrack,
    togglePlay,
    playNext,
    playPrev,
    seek,
  };
}
