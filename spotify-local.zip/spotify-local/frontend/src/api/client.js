const BASE = '/api';

async function request(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  return res.json();
}

export const api = {
  health: () => request('/health'),
  home: () => request('/home'),
  playlists: () => request('/playlists'),
  playlist: (id) => request(`/playlists/${id}`),
  album: (id) => request(`/albums/${id}`),
  search: (q) => request(`/tracks?q=${encodeURIComponent(q)}`),
};
