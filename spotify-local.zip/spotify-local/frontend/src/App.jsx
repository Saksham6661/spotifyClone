import { useState } from 'react';
import { PlayerProvider } from './hooks/PlayerContext';
import Sidebar from './components/Sidebar';
import PlayerBar from './components/PlayerBar';
import HomeView from './components/HomeView';
import SearchView from './components/SearchView';
import LibraryView from './components/LibraryView';
import DetailView from './components/DetailView';

export default function App() {
  const [view, setView] = useState('home');
  const [detail, setDetail] = useState(null);

  const openDetail = (kind, id) => {
    setDetail({ kind, id });
    setView('detail');
  };

  const renderMain = () => {
    if (view === 'detail' && detail) {
      return (
        <DetailView
          kind={detail.kind}
          id={detail.id}
          onBack={() => {
            setDetail(null);
            setView('library');
          }}
        />
      );
    }
    if (view === 'search') return <SearchView />;
    if (view === 'library') return <LibraryView onOpen={openDetail} />;
    return <HomeView onOpen={openDetail} />;
  };

  return (
    <PlayerProvider>
      <div className="app">
        <Sidebar
          view={view === 'detail' ? 'library' : view}
          onNavigate={(v) => {
            setDetail(null);
            setView(v);
          }}
        />
        <main className="main">{renderMain()}</main>
        <PlayerBar />
      </div>
    </PlayerProvider>
  );
}
