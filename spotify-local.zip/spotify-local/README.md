# Spotify Local

A self-contained Spotify-style music app with a **React UI** and **Express + SQLite API**, running entirely on your machine.

## Stack

| Layer | Tech |
|-------|------|
| Frontend | React 19 + Vite (port **5173**) |
| Backend | Express + better-sqlite3 (port **4000**) |
| Data | SQLite (`backend/data/spotify.db`) |
| Audio | Demo tracks via SoundHelix (streaming URLs) |

## Quick start

```bash
cd /Users/ashtiwar5/projects/spotify-local

# One-time setup (install deps + seed DB)
npm install
npm run setup

# Run API + UI together
npm run dev
```

Open **http://localhost:5173**

## What works end-to-end

- **Home** — playlists, albums, recent tracks from API
- **Search** — live search against tracks/artists/albums
- **Library** — browse playlists, open detail view
- **Playlist / Album detail** — track list with play
- **Player bar** — play/pause, prev/next, seek, volume, queue auto-advance

## API endpoints

```
GET /api/health
GET /api/home
GET /api/playlists
GET /api/playlists/:id
GET /api/albums/:id
GET /api/tracks?q=search
GET /api/tracks/:id
```

## Run separately

```bash
# Terminal 1 — API
cd backend && npm run dev

# Terminal 2 — UI
cd frontend && npm run dev

# Re-seed database
npm run seed
```

## Project layout

```
spotify-local/
├── backend/src/     # Express API + SQLite
├── frontend/src/    # React Spotify UI
└── package.json     # Root scripts (concurrently)
```

## Notes

- Audio streams from the internet (SoundHelix demo MP3s). You need network access to hear playback.
- Cover art uses picsum.photos placeholders.
- This is a demo project — not affiliated with Spotify.
