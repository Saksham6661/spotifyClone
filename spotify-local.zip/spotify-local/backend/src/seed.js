import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { initSchema, openDb } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, '..', 'data');
fs.mkdirSync(dataDir, { recursive: true });

const db = openDb();
initSchema(db);

db.exec('DELETE FROM playlist_tracks; DELETE FROM tracks; DELETE FROM albums; DELETE FROM artists; DELETE FROM playlists;');

const insertArtist = db.prepare('INSERT INTO artists (id, name, image_url) VALUES (?, ?, ?)');
const insertAlbum = db.prepare('INSERT INTO albums (id, title, artist_id, cover_url, year) VALUES (?, ?, ?, ?, ?)');
const insertTrack = db.prepare(
  'INSERT INTO tracks (id, title, album_id, duration_ms, audio_url, track_number) VALUES (?, ?, ?, ?, ?, ?)'
);
const insertPlaylist = db.prepare('INSERT INTO playlists (id, name, description, cover_url) VALUES (?, ?, ?, ?)');
const insertPlaylistTrack = db.prepare(
  'INSERT INTO playlist_tracks (playlist_id, track_id, position) VALUES (?, ?, ?)'
);

const artists = [
  { id: 1, name: 'Neon Pulse', image_url: 'https://picsum.photos/seed/neon/300/300' },
  { id: 2, name: 'Midnight Echo', image_url: 'https://picsum.photos/seed/echo/300/300' },
  { id: 3, name: 'Solar Drift', image_url: 'https://picsum.photos/seed/solar/300/300' },
  { id: 4, name: 'Ed Sheeran', image_url: 'https://picsum.photos/seed/edsheeran/300/300' },
];

const albums = [
  { id: 1, title: 'City Lights', artist_id: 1, cover_url: 'https://picsum.photos/seed/citylights/400/400', year: 2024 },
  { id: 2, title: 'After Hours', artist_id: 2, cover_url: 'https://picsum.photos/seed/afterhours/400/400', year: 2023 },
  { id: 3, title: 'Horizon Run', artist_id: 3, cover_url: 'https://picsum.photos/seed/horizon/400/400', year: 2025 },
  { id: 4, title: '÷ (Divide)', artist_id: 4, cover_url: 'https://picsum.photos/seed/divide/400/400', year: 2017 },
];

// Royalty-free demo audio (SoundHelix samples)
const tracks = [
  { id: 1, title: 'Downtown Drive', album_id: 1, duration_ms: 372000, audio_url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', track_number: 1 },
  { id: 2, title: 'Late Night Loop', album_id: 1, duration_ms: 425000, audio_url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', track_number: 2 },
  { id: 3, title: 'Velvet Sky', album_id: 2, duration_ms: 318000, audio_url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', track_number: 1 },
  { id: 4, title: 'Echo Chamber', album_id: 2, duration_ms: 290000, audio_url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3', track_number: 2 },
  { id: 5, title: 'Sunrise Sprint', album_id: 3, duration_ms: 340000, audio_url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3', track_number: 1 },
  { id: 6, title: 'Coastal Wind', album_id: 3, duration_ms: 305000, audio_url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3', track_number: 2 },
  { id: 7, title: 'Perfect', album_id: 4, duration_ms: 263000, audio_url: '/audio/perfect.mp3', track_number: 5 },
];

const playlists = [
  { id: 1, name: 'Today\'s Hits', description: 'Fresh picks for your day', cover_url: 'https://picsum.photos/seed/hits/400/400' },
  { id: 2, name: 'Focus Flow', description: 'Deep work without distraction', cover_url: 'https://picsum.photos/seed/focus/400/400' },
  { id: 3, name: 'Chill Vibes', description: 'Easy listening for unwinding', cover_url: 'https://picsum.photos/seed/chill/400/400' },
];

const playlistTracks = [
  [1, 7, 1], [1, 1, 2], [1, 3, 3], [1, 5, 4],
  [2, 2, 1], [2, 4, 2], [2, 6, 3],
  [3, 7, 1], [3, 1, 2], [3, 4, 3], [3, 6, 4],
];

const tx = db.transaction(() => {
  for (const a of artists) insertArtist.run(a.id, a.name, a.image_url);
  for (const al of albums) insertAlbum.run(al.id, al.title, al.artist_id, al.cover_url, al.year);
  for (const t of tracks) insertTrack.run(t.id, t.title, t.album_id, t.duration_ms, t.audio_url, t.track_number);
  for (const p of playlists) insertPlaylist.run(p.id, p.name, p.description, p.cover_url);
  for (const [pid, tid, pos] of playlistTracks) insertPlaylistTrack.run(pid, tid, pos);
});
tx();

console.log(`Seeded ${artists.length} artists, ${albums.length} albums, ${tracks.length} tracks, ${playlists.length} playlists.`);
