import cors from 'cors';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { initSchema, openDb } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, '..', 'data');
fs.mkdirSync(dataDir, { recursive: true });

const db = openDb();
initSchema(db);

const trackCount = db.prepare('SELECT COUNT(*) AS n FROM tracks').get().n;
if (trackCount === 0) {
  console.log('Database empty — run: npm run seed');
}

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

function trackSelect() {
  return `
    SELECT
      t.id,
      t.title,
      t.duration_ms,
      t.audio_url,
      t.track_number,
      a.id AS album_id,
      a.title AS album_title,
      a.cover_url AS album_cover,
      ar.id AS artist_id,
      ar.name AS artist_name
    FROM tracks t
    JOIN albums a ON a.id = t.album_id
    JOIN artists ar ON ar.id = a.artist_id
  `;
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, tracks: trackCount });
});

app.get('/api/home', (_req, res) => {
  const playlists = db.prepare('SELECT id, name, description, cover_url FROM playlists ORDER BY id').all();
  const recent = db.prepare(`${trackSelect()} ORDER BY t.id LIMIT 6`).all();
  const albums = db
    .prepare(
      `SELECT a.id, a.title, a.cover_url, a.year, ar.name AS artist_name
       FROM albums a JOIN artists ar ON ar.id = a.artist_id ORDER BY a.id`
    )
    .all();
  res.json({ playlists, recent, albums });
});

app.get('/api/playlists', (_req, res) => {
  const rows = db
    .prepare(
      `SELECT p.id, p.name, p.description, p.cover_url,
              COUNT(pt.track_id) AS track_count
       FROM playlists p
       LEFT JOIN playlist_tracks pt ON pt.playlist_id = p.id
       GROUP BY p.id
       ORDER BY p.id`
    )
    .all();
  res.json(rows);
});

app.get('/api/playlists/:id', (req, res) => {
  const playlist = db
    .prepare('SELECT id, name, description, cover_url FROM playlists WHERE id = ?')
    .get(req.params.id);
  if (!playlist) return res.status(404).json({ error: 'Playlist not found' });

  const tracks = db
    .prepare(
      `${trackSelect()}
       JOIN playlist_tracks pt ON pt.track_id = t.id
       WHERE pt.playlist_id = ?
       ORDER BY pt.position`
    )
    .all(req.params.id);

  res.json({ ...playlist, tracks });
});

app.get('/api/albums/:id', (req, res) => {
  const album = db
    .prepare(
      `SELECT a.id, a.title, a.cover_url, a.year, ar.id AS artist_id, ar.name AS artist_name
       FROM albums a JOIN artists ar ON ar.id = a.artist_id WHERE a.id = ?`
    )
    .get(req.params.id);
  if (!album) return res.status(404).json({ error: 'Album not found' });

  const tracks = db
    .prepare(`${trackSelect()} WHERE t.album_id = ? ORDER BY t.track_number`)
    .all(req.params.id);

  res.json({ ...album, tracks });
});

app.get('/api/tracks', (req, res) => {
  const q = (req.query.q || '').trim();
  if (!q) {
    return res.json(db.prepare(`${trackSelect()} ORDER BY t.id`).all());
  }
  const like = `%${q}%`;
  const rows = db
    .prepare(
      `${trackSelect()}
       WHERE t.title LIKE ? OR ar.name LIKE ? OR a.title LIKE ?
       ORDER BY t.title LIMIT 50`
    )
    .all(like, like, like);
  res.json(rows);
});

app.get('/api/tracks/:id', (req, res) => {
  const track = db.prepare(`${trackSelect()} WHERE t.id = ?`).get(req.params.id);
  if (!track) return res.status(404).json({ error: 'Track not found' });
  res.json(track);
});

app.listen(PORT, () => {
  console.log(`Spotify API running at http://localhost:${PORT}`);
});
