import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { openDb } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const audioDir = path.join(__dirname, '..', 'audio');

const source = process.argv[2];
const trackId = Number(process.argv[3] || 7);
const destName = process.argv[4] || 'perfect.mp3';

if (!source) {
  console.error('Usage: npm run import-audio -- <path-to-mp3> [trackId] [filename]');
  console.error('Example: npm run import-audio -- ~/Music/Perfect.mp3');
  process.exit(1);
}

const resolved = path.resolve(source);
if (!fs.existsSync(resolved)) {
  console.error(`File not found: ${resolved}`);
  process.exit(1);
}

fs.mkdirSync(audioDir, { recursive: true });
const dest = path.join(audioDir, destName);
fs.copyFileSync(resolved, dest);

const audioUrl = `/audio/${destName}`;
const db = openDb();
const result = db
  .prepare('UPDATE tracks SET audio_url = ? WHERE id = ?')
  .run(audioUrl, trackId);

if (result.changes === 0) {
  console.error(`No track with id ${trackId}. Run npm run seed first.`);
  process.exit(1);
}

console.log(`Imported ${resolved}`);
console.log(`Saved to backend/audio/${destName}`);
console.log(`Track ${trackId} now plays from ${audioUrl}`);
